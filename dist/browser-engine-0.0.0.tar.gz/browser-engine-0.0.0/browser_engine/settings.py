import os

AUTH_TOKEN = os.environ.get("AUTH_TOKEN", "iamlazydeveloper")
SELENIUM_HOST = os.environ.get("SELENIUM_HOST", "http://127.0.0.1:4444")
